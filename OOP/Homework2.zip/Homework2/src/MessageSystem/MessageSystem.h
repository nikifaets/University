#pragma once

#include <string>
#include <iostream>

namespace message{


    void print_info(std::string desc, int var);
    void print_string(std::string str);
}