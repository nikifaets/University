#include "MessageSystem.h"

void message::print_info(std::string desc, int var){

        std::cout << desc << " " << var << std::endl;
}

void message::print_string(std::string str){

        std::cout << str << std::endl;
}