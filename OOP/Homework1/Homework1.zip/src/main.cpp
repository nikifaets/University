#include <iostream>
#include "Card/Card.h"
#include "Deck/Deck.h"
#include "Game/Game.h"

using namespace std;

int main(){

	Game game;
}