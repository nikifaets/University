#pragma once

class Parser{

public:
	bool validate_int(int val, int lower, int upper);
};