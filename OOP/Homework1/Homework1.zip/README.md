Build and run:
```
mkdir build
cd build
cmake ..
make
./Blackjack
```
Tested with g++ 9.3.0 on Arch Linux
