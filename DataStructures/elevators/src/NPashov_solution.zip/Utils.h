#pragma once
class Utils{


    public:
    
    static int sign(int n);
};