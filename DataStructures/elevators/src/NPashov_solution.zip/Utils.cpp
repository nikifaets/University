#include "Utils.h"

int Utils::sign(int n){

    return (0 < n) - (0 > n);

}